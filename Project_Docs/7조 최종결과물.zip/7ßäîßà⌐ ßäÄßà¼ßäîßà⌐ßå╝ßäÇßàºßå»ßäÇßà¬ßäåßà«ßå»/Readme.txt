[제출 파일 List]

1. 머신러닝 프로젝트 보고서 (PDF)
	- Appendix-1. Team Data set
	- Appendix-2. 노트북 파일별 설명
	- Appendix-3. 프로젝트 수행일지 모음
	- Appendix-4. 기여도
	
2. 6개의 노트북 파일 (ipynb)

3. 최종 발표 (PPTX/PDF)